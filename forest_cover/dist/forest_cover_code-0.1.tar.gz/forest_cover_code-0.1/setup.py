from setuptools import setup

setup(
    name='forest_cover_code',
    version='0.1',
    scripts=['predictor.py', 'preprocess.py'])